import {
  useEffect,
  useState,
} from "react";

import {
  initializeWorkspaceForOrganization,
} from "../../services/workspaces";

import type {
  Organization,
} from "../../types/organizations";

import {
  createOrganization,
  updateOrganization,
  deleteOrganization,  
} from "../../services/organizations";

import "./EditOrganizationDialog.css";


type Props = {
  open: boolean;

  organization:
    | Organization
    | null;

  onClose: () => void;

  onSaved: () => void;
};



type OrganizationForm = {
  name: string;
  slug: string;
  active: boolean;
  initializeWorkspace: boolean;
};



export default function EditOrganizationDialog({
  open,
  organization,
  onClose,
  onSaved,
}: Props) {


  const [
    saving,
    setSaving,
  ] =
    useState(false);



  const [
    error,
    setError,
  ] =
    useState<string | null>(null);



  const [
    form,
    setForm,
  ] =
useState<OrganizationForm>({
  name: "",
  slug: "",
  active: true,
  initializeWorkspace: false,
});



  useEffect(() => {

    if (!open) {
      return;
    }


    setError(null);


    if (organization) {

setForm({
  name:
    organization.name,

  slug:
    organization.slug,

  active:
    organization.active,

  initializeWorkspace:
    false,
});

    } else {

      setForm({
        name: "",
        slug: "",
        active: true,
        initializeWorkspace: false,
      });

    }

  }, [
    organization,
    open,
  ]);



  if (!open) {
    return null;
  }



  async function handleSave() {

    setSaving(true);

    setError(null);


    try {


if (organization) {

  await updateOrganization(
    organization.id,
    {
      name: form.name,
      slug: form.slug,
      active: form.active,
    },
  );


  if (form.initializeWorkspace) {

    await initializeWorkspaceForOrganization(
      organization.id,
    );

  }

      } else {


await createOrganization(
  form.name,
  form.slug,
  form.initializeWorkspace,
);


      }


      onSaved();

      onClose();


    } catch (err) {


      console.error(
        "Organization save failed:",
        err,
      );


      setError(
        err instanceof Error
          ? err.message
          : "Unable to save organization.",
      );


    } finally {


      setSaving(false);


    }

  }

  async function handleDelete() {

  if (!organization) {
    return;
  }


  const confirmed =
    window.confirm(
      `Remove ${organization.name} from Platform? Its Store seller will be suspended and all public listings will be archived. Historical records are retained for audit.`,
    );


  if (!confirmed) {
    return;
  }


  setSaving(true);


  try {

    await deleteOrganization(
      organization.id,
    );

    onSaved();
    onClose();

  } catch (err) {

    setError(
      err instanceof Error
        ? err.message
        : "Unable to delete organization.",
    );

  } finally {

    setSaving(false);

  }

}


  return (

    <div className="dialog-backdrop">


      <div className="edit-organization-dialog">


        <div className="dialog-header">


          <h2>

            {
              organization
                ? "Edit Organization"
                : "New Organization"
            }

          </h2>



          <button
            className="dialog-close"
            onClick={onClose}
          >
            ✕
          </button>


        </div>




        <div className="dialog-body">


          {error && (

            <div className="dialog-error">

              {error}

            </div>

          )}



          <div className="form-group">

            <label>
              Organization Name
            </label>


            <input
              value={
                form.name
              }

              onChange={(e) =>
                setForm({
                  ...form,

                  name:
                    e.target.value,
                })
              }
            />

          </div>





          <div className="form-group">

            <label>
              Slug
            </label>


            <input
              value={
                form.slug
              }

              onChange={(e) =>
                setForm({
                  ...form,

                  slug:
                    e.target.value
                      .toLowerCase()
                      .replace(
                        /\s+/g,
                        "-",
                      ),
                })
              }
            />

          </div>



          {organization && (
            <div className="organization-sync-note">
              Organization name and slug are controlled here in Platform.
              Changes also update the linked Store seller identity.
            </div>
          )}

<div className="checkbox-group">

  <label>

    <input
      type="checkbox"

      checked={
        form.initializeWorkspace
      }

      onChange={(e) =>
        setForm({
          ...form,

          initializeWorkspace:
            e.target.checked,
        })
      }
    />

    Initialize OTLES Workspace

  </label>

</div>



        </div>





<div className="dialog-footer">

{organization && (
    <button
      className="danger-button"
      onClick={handleDelete}
      disabled={saving}
    >
      Delete
    </button>
  )}

  <div className="footer-actions">

    <button
      className="secondary-button"
      onClick={onClose}
      disabled={saving}
    >
      Cancel
    </button>



    <button
      className="save-button"
      onClick={handleSave}
      disabled={saving}
    >
      Save
    </button>


    </div>
      </div>
    </div>
</div>

  );  

}